local LibNP = LibStub("LibNameplate-1.0")

local find = string.find

local THROTTLE_TIME = 0.01

local EventHandler = CreateFrame("Frame")

EventHandler:SetScript("OnUpdate", function(self, elapsed)
	self.elapsedTime = (self.elapsedTime or THROTTLE_TIME) + elapsed
	
	if THROTTLE_TIME > self.elapsedTime then return end
		
	for _, f in LibNP:IteratePlates() do
		local nameText = LibNP:GetName(f)
		
		if nameText == "Earthbind Totem" then
			local r = LibNP:GetNameRegion(f)
			if r and r.SetTextColor then
				r:SetTextColor(0, 1, 0.5)
			end
		elseif nameText == "Cleansing Totem" then
			local r = LibNP:GetNameRegion(f)
			if r and r.SetTextColor then
				r:SetTextColor(0.5, 1, 0)
			end
		elseif nameText == "Tremor Totem" then
			local r = LibNP:GetNameRegion(f)
			if r and r.SetTextColor then
				r:SetTextColor(0.5, 0, 1)
			end
		elseif nameText == "Grounding Totem" then
			local r = LibNP:GetNameRegion(f)
			if r and r.SetTextColor then
				r:SetTextColor(1, 0, 0.5)
			end
		elseif nameText == "Mana Tide Totem" then
			local r = LibNP:GetNameRegion(f)
			if r and r.SetTextColor then
				r:SetTextColor(0, 0.5, 1)
			end
		elseif find(nameText, "Searing Totem") or find(nameText, "Magma Totem") then
			local r = LibNP:GetNameRegion(f)
			if r and r.SetTextColor then
				r:SetTextColor(1, 0.5, 0)
			end
		elseif find(nameText, "Fire Resistance Totem") or
			   find(nameText, "Flametongue Totem") or
			   find(nameText, "Frost Resistance Totem") or
			   find(nameText, "Healing Stream Totem") or
			   find(nameText, "Mana Spring Totem") or
			   find(nameText, "Nature Resistance Totem") or
			   find(nameText, "Stoneclaw Totem") or
			   find(nameText, "Stoneskin Totem") or
			   find(nameText, "Strength of Earth Totem") or
			   find(nameText, "Totem of Wrath") or
			   nameText == "Windfury Totem" or
			   nameText == "Wrath of Air Totem" or
			   nameText == "Earth Elemental Totem" or
			   nameText == "Fire Elemental Totem" or
			   nameText == "Sentry Totem" then
			f:Hide()
		end
	end
	
	self.elapsedTime = 0
end)